Dawaa Tracker - CS475 project (Gradle project, opens directly in IntelliJ IDEA)

Before opening:
1. Install JDK 17 (IntelliJ can download it: File > Project Structure > SDKs > Add SDK > Download JDK).
2. Install the Android SDK (API 34). Easiest way: install Android Studio once and open
   Tools > SDK Manager, or install the "Android SDK Command-line Tools".
3. In IntelliJ: Settings > Plugins > make sure the "Android" plugin is enabled.

Open and run:
1. Unzip Project.zip.
2. IntelliJ: File > Open > select the unzipped folder (the one that has settings.gradle).
3. Wait for Gradle sync. If it asks for the SDK path, create a file called local.properties
   in the project root with one line, for example:
      sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk
4. Project Structure > Project > set the SDK to JDK 17. Settings > Build Tools > Gradle > Gradle JDK = 17.
5. Create a virtual device: Tools > Device Manager (or from Android Studio's AVD Manager), then press Run on the "app" configuration.
